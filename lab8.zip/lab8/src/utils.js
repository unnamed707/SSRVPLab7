import { v4 as uuidv4 } from 'uuid';

export const generateDummyFeedback = (count) => {
    const feedback = [];
    for (let i = 0; i < count; i++) {
      feedback.push({
        id: uuidv4(),
        text: `This is feedback item number ${i + 1}.  It's a great product!`,
        author: `user${i + 1}`,
        isBlocked: false,
      });
    }
    return feedback;
  };
