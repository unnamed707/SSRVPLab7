// src/App.jsx
import React, { useState, useEffect, useCallback } from 'react';
import Header from './components/Header';
import LoginForm from './components/LoginForm';
import RegistrationForm from './components/RegistrationForm';
import Profile from './components/Profile';
import AdminPanel from './components/AdminPanel';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import MainApp from './components/MainApp'; // Import MainApp
import { v4 as uuidv4 } from 'uuid'; // Import uuidv4


const App = () => {
  const [user, setUser] = useState(null);
  const [showLogin, setShowLogin] = useState(false);
  const [showRegistration, setShowRegistration] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [feedback, setFeedback] = useState([]);
  const [users, setUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  const fetchFeedback = useCallback(async () => {
    setIsLoading(true);
    try {
      const response = await fetch(
        `http://localhost:3001/feedback?_page=1&_limit=10`
      );
      const data = await response.json();
      setIsLoading(false);
      setFeedback(data);
    } catch (error) {
      console.error('Error fetching feedback:', error);
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchFeedback();
  }, [fetchFeedback]);

  const handleLogin = (userData) => {
    if (userData.isBlocked) {
      alert("This user is blocked. Please contact an administrator.");
      return;
    }
    setUser(userData);
    localStorage.setItem('user', JSON.stringify(userData));
    setShowLogin(false);
    fetchUsers();
  };

  const handleRegister = (userData) => {
    setUser(userData);
    localStorage.setItem('user', JSON.stringify(userData));
    setShowRegistration(false);
    fetchUsers();
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  const handleUpdateProfile = (updatedUser) => {
    setUser(updatedUser);
    localStorage.setItem('user', JSON.stringify(updatedUser));
    setShowProfile(false);
    fetchUsers();
  };

  const handleAddFeedback = async (newFeedback) => {
    try {
      const response = await fetch('http://localhost:3001/feedback', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ ...newFeedback, id: uuidv4() }),
      });
      if (response.ok) {
        fetchFeedback();
      } else {
        console.error('Failed to add feedback');
      }
    } catch (error) {
      console.error('Error adding feedback:', error);
    }
  };

  const handleDeleteFeedback = async (id) => {
    try {
      const response = await fetch(`http://localhost:3001/feedback/${id}`, {
        method: 'DELETE',
      });
      if (response.ok) {
        fetchFeedback();
      } else {
        console.error('Failed to delete feedback');
      }
    } catch (error) {
      console.error('Error deleting feedback:', error);
    }
  };

  const handleBlockFeedback = async (id) => {
    try {
      const feedbackItem = feedback.find(item => item.id === id);
      if (!feedbackItem) return;

      const response = await fetch(`http://localhost:3001/feedback/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ isBlocked: true, text: 'Blocked' }),
      });

      if (response.ok) {
        fetchFeedback();
      } else {
        console.error('Failed to block feedback');
      }
    } catch (error) {
      console.error('Error blocking feedback:', error);
    }
  };
  const fetchUsers = useCallback(async () => {
    try {
      const response = await fetch('http://localhost:3001/users');
      const data = await response.json();
      setUsers(data);
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  }, []);

  const handleDeleteUser = async (username) => {
    try {
      const response = await fetch(`http://localhost:3001/users?username=${username}`);
      const data = await response.json();
      if (data && data.length > 0) {
        const userToDelete = data[0];
        const deleteResponse = await fetch(`http://localhost:3001/users/${userToDelete.id}`, {
          method: 'DELETE',
        });

        if (deleteResponse.ok) {
          fetchUsers();
        } else {
          console.error('Failed to delete user');
        }
      } else {
        console.error('User not found');
      }
    } catch (error) {
      console.error('Error deleting user:', error);
    }
  };

  const handleBlockUser = async (username, block) => {
    try {
      const response = await fetch(`http://localhost:3001/users?username=${username}`);
      const data = await response.json();
      if (data && data.length > 0) {
        const userToUpdate = data[0];

        const updateResponse = await fetch(`http://localhost:3001/users/${userToUpdate.id}`, {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ isBlocked: block }),
        });

        if (updateResponse.ok) {
          fetchUsers();
        } else {
          console.error('Failed to block user');
        }
      } else {
        console.error('User not found');
      }
    } catch (error) {
      console.error('Error blocking user:', error);
    }

    if (user && user.username === username) {
      handleLogout();
    }
  };

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  return (
    <BrowserRouter>
      <div>
        <Header
          user={user}
          onLoginClick={() => setShowLogin(true)}
          onRegisterClick={() => setShowRegistration(true)}
          onProfileClick={showProfile ? ()=> setShowProfile(false) : ()=> setShowProfile(true) }
          onLogout={handleLogout}
        />

        {showLogin && <LoginForm onLogin={handleLogin} onClose={() => setShowLogin(false)} />}
        {showRegistration && <RegistrationForm onRegister={handleRegister} onClose={() => setShowRegistration(false)} />}
        {showProfile && <Profile user={user} onUpdateProfile={handleUpdateProfile} onClose={() => setShowProfile(false)} />}

        <Routes>
          <Route
            path="/"
            element={
              <MainApp
                user={user}
                feedback={feedback}
                setFeedback={setFeedback}
                handleAddFeedback={handleAddFeedback}
                handleDeleteFeedback={handleDeleteFeedback}
                handleBlockFeedback={handleBlockFeedback}
                isLoading={isLoading}
              />
            }
          />
          <Route
            path="/admin"
            element={
              user && user.role === 'admin' ? (
                
                <AdminPanel
                  users={users}
                  onDeleteUser={handleDeleteUser}
                  onBlockUser={handleBlockUser}
                  loggedInUser={user}
                  feedback={feedback}
                  onAddFeedback={handleAddFeedback}
                  onDeleteFeedback={handleDeleteFeedback}
                  onBlockFeedback={handleBlockFeedback}
                />
              ) : (
                <p>Access denied.</p>
              )
            }
          />
        </Routes>
      </div>
    </BrowserRouter>
  );
};

export default App;
