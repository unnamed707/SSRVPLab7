// src/components/MainApp.jsx
import React, { useState, useEffect, useCallback } from 'react';
import FeedbackList from './FeedbackList';
import FeedbackForm from './FeedbackForm';

const MainApp = ({
  user,
  feedback: initialFeedback,
  setFeedback,
  handleAddFeedback,
  handleDeleteFeedback,
  handleBlockFeedback,
  isLoading: initialIsLoading,
}) => {
  const [feedback, setFeedbackState] = useState(initialFeedback);
  const [isLoading, setIsLoading] = useState(initialIsLoading);
  const [hasMore, setHasMore] = useState(true);
  const [page, setPage] = useState(1);  // Start at page 1
  const pageSize = 10;

  const fetchMoreData = useCallback(async () => {
    if (!hasMore) return;

    setIsLoading(true);
    try {
      const response = await fetch(
        `http://localhost:3001/feedback?_page=${page + 1}&_limit=${pageSize}`
      );

      const newData = await response.json();

      if (newData.length === 0) {
        setHasMore(false);
      } else {
        setFeedbackState((prevFeedback) => [...prevFeedback, ...newData]);
        setPage((prevPage) => prevPage + 1);
      }
    } catch (error) {
      console.error('Error fetching more feedback:', error);
    } finally {
      setIsLoading(false);
    }
  }, [hasMore, page, pageSize]);

  useEffect(() => {
    setFeedbackState(initialFeedback);
    setIsLoading(initialIsLoading);
    setHasMore(true);
    setPage(1);  // Reset to page 1 when initial feedback changes
  }, [initialFeedback, initialIsLoading]);

  return (
    <div>
      {user ? (
        <div>
          <p>Welcome, {user.username}!</p>
          <FeedbackForm user={user} onAddFeedback={handleAddFeedback} />
          <FeedbackList
            feedback={feedback}
            user={user}
            onDeleteFeedback={handleDeleteFeedback}
            onBlockFeedback={handleBlockFeedback}
            hasMore={hasMore}
            fetchMoreData={fetchMoreData}
          />
        </div>
      ) : (
        <div>
          <p>Please login or register to leave feedback.</p>
          <FeedbackList
            feedback={feedback}
            user={user}
            onDeleteFeedback={handleDeleteFeedback}
            onBlockFeedback={handleBlockFeedback}
            hasMore={hasMore}
            fetchMoreData={fetchMoreData}
          />
        </div>
      )}
    </div>
  );
};

export default MainApp;
