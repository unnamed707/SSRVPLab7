// src/components/Header.jsx
import React from 'react';
import Button from '@mui/material/Button';
import { Link } from 'react-router-dom';

const Header = ({ user, onLoginClick, onRegisterClick, onProfileClick, onLogout }) => {
  return (
    <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px' }}>
      <h1>My App</h1>
      <div>
        {user ? (
          <>
            <Button color="inherit" onClick={onProfileClick}>Profile</Button>
            {user.role === 'admin' && (
              <Link to="/admin" style={{ textDecoration: 'none', color: 'inherit' }}>
                <Button color="inherit">Admin Panel</Button>
              </Link>
            )}
            <Button color="inherit" onClick={onLogout}>Logout</Button>
          </>
        ) : (
          <>
            <Button color="inherit" onClick={onLoginClick}>Login</Button>
            <Button color="inherit" onClick={onRegisterClick}>Register</Button>
          </>
        )}
      </div>
    </header>
  );
};

export default Header;
