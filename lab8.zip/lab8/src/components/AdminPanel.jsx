// src/components/AdminPanel.jsx
import React, { useMemo, useState, useCallback, useEffect } from 'react';
import { MaterialReactTable } from 'material-react-table';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import Button from '@mui/material/Button';
import FeedbackList from './FeedbackList';
import FeedbackForm from './FeedbackForm';
import { v4 as uuidv4 } from 'uuid';
import { useNavigate } from 'react-router-dom';

const AdminPanel = ({
    users,
    onDeleteUser,
    onBlockUser,
    loggedInUser,
    feedback,
    onAddFeedback,
    onDeleteFeedback,
    onBlockFeedback,
  }) => {
    const isAdmin = loggedInUser && loggedInUser.role === 'admin';
    const navigate = useNavigate();
    const handleBack = () => {
        navigate('/')
    }
    const columns = useMemo(
      () => [
        {
          accessorKey: 'username',
          header: 'Username',
          enableColumnDragging: true,
        },
        {
          accessorKey: 'role',
          header: 'Role',
          enableColumnDragging: true,
        },
        {
          accessorKey: 'isBlocked',
          header: 'Blocked',
          Cell: ({ row }) => (row.original.isBlocked ? 'Yes' : 'No'),
        },
        {
          id: 'actions',
          header: 'Actions',
          Cell: ({ row }) => (
            <div>
              {row.original.username !== loggedInUser.username && (
                <>
                  <Button
                    color="secondary"
                    onClick={() => onDeleteUser(row.original.username)}
                    disabled={row.original.role === 'admin'}
                  >
                    Delete
                  </Button>
                  <Button
                    color={row.original.isBlocked ? 'success' : 'warning'}
                    onClick={() => onBlockUser(row.original.username, !row.original.isBlocked)}
                  >
                    {row.original.isBlocked ? 'Unblock' : 'Block'}
                  </Button>
                </>
              )}
            </div>
          ),
          enableSorting: false,
          enableColumnDragging: false,
        },
      ],
      [onDeleteUser, onBlockUser, loggedInUser]
    );

    const feedbackColumns = useMemo(
        () => [
          {
            accessorKey: 'text',
            header: 'Feedback',
            Cell: ({ row }) => (
              <span style={{ textDecoration: row.original.isBlocked ? 'line-through' : 'none' }}>
                {row.original.text}
              </span>
            ),
          },
          {
            accessorKey: 'author',
            header: 'Author',
          },
          {
            id: 'actions',
            header: 'Actions',
            Cell: ({ row }) => (
              <div>
                {isAdmin && (
                  <Button
                    onClick={() => onBlockFeedback(row.original.id)}
                    size="small"
                    color="warning"
                    disabled={row.original.isBlocked}
                  >
                    {row.original.isBlocked ? 'Blocked' : 'Block'}
                  </Button>
                )}
                {loggedInUser && (isAdmin || loggedInUser.username === row.original.author) && (
                  <Button onClick={() => onDeleteFeedback(row.original.id)} size="small" color="secondary">
                    Delete
                  </Button>
                )}
              </div>
            ),
            enableSorting: false,
            enableColumnDragging: false,
          },
        ],
        [onBlockFeedback, onDeleteFeedback, loggedInUser, isAdmin]
      );

    const [feedbackData, setFeedbackData] = useState([]);

    useEffect(() => {
        const fetchFeedback = async () => {
            try {
              const response = await fetch(
                `http://localhost:3001/feedback`
              );
              const data = await response.json();
              setFeedbackData(data);
            } catch (error) {
              console.error('Error fetching feedback:', error);
            }
          };
          fetchFeedback();
    }, [])
  
  return (
    <div>
        <Button onClick={handleBack}>Back</Button>
      <DialogTitle>Admin Panel</DialogTitle>
      <DialogContent>
        <h3>User Management</h3>
        <MaterialReactTable
          columns={columns}
          data={users}
          enableColumnOrdering
          muiTablePaperProps={{
            elevation: 3,
          }}
          muiTableHeadCellProps={{
            style: {
              fontWeight: 'bold',
            },
          }}
        />

        <h3>Feedback Management</h3>
        <FeedbackForm user={loggedInUser} onAddFeedback={onAddFeedback} />
          <MaterialReactTable
              columns={feedbackColumns}
              data={feedbackData}
              muiTablePaperProps={{
                elevation: 3,
              }}
              muiTableHeadCellProps={{
                style: {
                  fontWeight: 'bold',
                },
              }}
            />
      </DialogContent>
    </div>
  );
};

export default AdminPanel;
