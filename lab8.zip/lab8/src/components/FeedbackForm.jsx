// src/components/FeedbackForm.jsx
import React, { useState } from 'react';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';

const FeedbackForm = ({ onAddFeedback, user }) => {
  const [text, setText] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (text.trim() === '') return;
    onAddFeedback({ text: text, author: user.username });
    setText('');
  };

  if (!user) {
    return <p>Please log in to leave feedback.</p>;
  }

  return (
    <form onSubmit={handleSubmit}>
      <TextField
        label="Your Feedback"
        multiline
        rows={4}
        fullWidth
        variant="outlined"
        value={text}
        onChange={(e) => setText(e.target.value)}
      />
      <Button type="submit" variant="contained" color="primary" style={{ marginTop: '10px' }}>
        Submit Feedback
      </Button>
    </form>
  );
};

export default FeedbackForm;
