// src/components/UserTable.jsx
import React, { useMemo } from 'react';
import { MaterialReactTable } from 'material-react-table'; // Измененный импорт

const UserTable = ({ users }) => {
  const columns = useMemo(
    () => [
      {
        accessorKey: 'username',
        header: 'Username',
        enableColumnDragging: true,
      },
      {
        accessorKey: 'role',
        header: 'Role',
        enableColumnDragging: true,
      },
    ],
    [],
  );

  return (
    <MaterialReactTable
      columns={columns}
      data={users}
      enableColumnOrdering
      muiTablePaperProps={{
        elevation: 3,
      }}
      muiTableHeadCellProps={{
        style: {
          fontWeight: 'bold',
        },
      }}
    />
  );
};

export default UserTable;
