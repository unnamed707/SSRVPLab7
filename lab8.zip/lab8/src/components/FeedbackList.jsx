// src/components/FeedbackList.jsx
import React, { useState, useEffect, useCallback } from 'react';
import { MaterialReactTable } from 'material-react-table';
import Button from '@mui/material/Button';
import InfiniteScroll from 'react-infinite-scroll-component';

const FeedbackList = ({ feedback, user, onDeleteFeedback, onBlockFeedback, hasMore, fetchMoreData }) => {
  const isAdmin = user && user.role === 'admin';

  const columns = React.useMemo(
    () => [
      {
        accessorKey: 'text',
        header: 'Feedback',
        Cell: ({ row }) => (
          <span style={{ textDecoration: row.original.isBlocked ? 'line-through' : 'none' }}>
            {row.original.text}
          </span>
        ),
      },
      {
        accessorKey: 'author',
        header: 'Author',
      },
      {
        id: 'actions',
        header: 'Actions',
        Cell: ({ row }) => (
          <div>
            {isAdmin && (
              <Button
                onClick={() => onBlockFeedback(row.original.id)}
                size="small"
                color="warning"
                disabled={false}
              >
                {!row.original.isBlocked ? 'Block' : 'Unblock'}
              </Button>
            )}
            {user && (isAdmin || user.username === row.original.author) && (
              <Button onClick={() => onDeleteFeedback(row.original.id)} size="small" color="secondary">
                Delete
              </Button>
            )}
          </div>
        ),
        enableSorting: false,
        enableColumnDragging: false,
      },
    ],
    [onBlockFeedback, onDeleteFeedback, user, isAdmin]
  );

  return (
    <div>
      <h2>Feedbacks:</h2>
      <InfiniteScroll
        dataLength={feedback.length}
        next={fetchMoreData}
        hasMore={hasMore}
        loader={<h4></h4>}
        endMessage={
          <p style={{ textAlign: 'center' }}>
            <b>Yay! You have seen it all</b>
          </p>
        }
      >
        <MaterialReactTable
          columns={columns}
          data={feedback}
          muiTablePaperProps={{
            elevation: 3,
          }}
          muiTableHeadCellProps={{
            style: {
              fontWeight: 'bold',
            },
          }}
        />
      </InfiniteScroll>
    </div>
  );
};

export default FeedbackList;
