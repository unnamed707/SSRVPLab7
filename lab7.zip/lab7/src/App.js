import React, { useState, useMemo, useCallback } from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import Header from './components/Header';
import Menu from './components/Menu';
import Footer from './components/Footer';
import Home from './pages/Home';
import About from './pages/About';
import AboutApp from './pages/AboutApp';
import LabDescription from './components/LabDescription';
import LoginForm from './components/LoginForm';
import RegistrationForm from './components/RegistrationForm';
import ProfileSettings from './pages/ProfileSettings';
import Feedback from './pages/Feedback';
import { useLoginState } from './hooks/useLoginState';

function App() {
  const [darkMode, setDarkMode] = useState(false);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const { isLoggedIn, login, logout } = useLoginState();
  const [reviews, setReviews] = useState([]);

  const theme = useMemo(
    () =>
      createTheme({
        palette: {
          mode: darkMode ? 'dark' : 'light',
          primary: {
            main: darkMode ? '#1976d2' : '#90caf9',
          },
          secondary: {
            main: '#dc004e',
          },
        },
      }),
    [darkMode],
  );

  const toggleDarkMode = useCallback(() => {
    setDarkMode(!darkMode);
  }, [darkMode]);

  const toggleDrawer = useCallback(() => {
    setIsDrawerOpen(!isDrawerOpen);
  }, [isDrawerOpen]);

  const handleLogin = useCallback((username, password) => {
    const storedPassword = localStorage.getItem(`password_${username}`); // Получаем сохраненный пароль
    if (storedPassword && storedPassword === password) { // Проверяем пароль
      login(username);
      return true;
    }
    return false;
  }, [login]);

  const handleLogout = useCallback(() => {
    logout();
  }, [logout]);

  const handleRegistration = useCallback((username, password) => {
    localStorage.setItem(`password_${username}`, password); // Сохраняем пароль
    login(username);
  }, [login]);

  const addReview = useCallback((review) => {
    setReviews((prevReviews) => [...prevReviews, { ...review, author: isLoggedIn }]);
  }, [isLoggedIn, setReviews]);

  const deleteReview = useCallback((id) => {
    setReviews((prevReviews) => prevReviews.filter((review, index) => index !== id));
  }, [setReviews]);

  const labWorks = [
    { id: 1, title: 'Лабораторная работа 1', path: '/lab1', description: `Реализовать форму аутентификации пользователя (<form>)\nРеализовать скрипт очистки данных формы\nРеализовать скрипт отправки данных формы с помощью listener submit.\nБез отправки на сервер провести валидацию введенных данных, если login=="admin" & pass=="admin" вывести сообщение об успехе, иначе сообщение о неуспехе\nРеализовать скрипт сохранения учетных данных и автоподстановку оных с помощью localStorage` },
    { id: 2, title: 'Лабораторная работа 2', path: '/lab2', description: `Создать "Hello World" приложение на основе React.\nДля создания можно использовать create-react-app или vite\nРеализовать компонент кнопку, контейнер и использовать их на странице\nРеализовать шаблон страницы и разместить на нем компоненты навигации` },
    { id: 3, title: 'Лабораторная работа 3', path: '/lab3', description: `Продолжаем задание "Реализовать шаблон страницы и разместить на нем компоненты навигации" (Можно использовать готовые библиотеки Mui/Bootstrap и тд)\nРеализуем компоненты Header, Footer, Menu и Content\nВ меню выводим список лабораторных работ\nВ Content  выводим содержимое лабораторной работы` },
    { id: 4, title: 'Лабораторная работа 4', path: '/lab4', description: `Внедрить в проект react-router\nВ меню проекта реализовать ссылки переходы \nВ Content реализовать обработчик роутов\nВнедрить в проект redux\nРеализовать несколько action и reducer, например increment/ decrement счетчика` },
    { id: 5, title: 'Лабораторная работа 5', path: '/lab5', description: `Реализовать форму регистрации и форму авторизации с помощью React-hook-forms или Formik (валидация полей)\nРеализовать блок обратной связи. Форма обратной связи и список отзывов\nОбработать submit форм через useCallback функции по примеру Лабораторной работы 1\nРеализовать кастомный хук useLoginState\nВыдает true / false -  статус авторизации\nЕсли true - отрисовать приложение, иначе форму авторизации\nХранить статус авторизации можно в redux, context или localStore\nРеализовать в правом верхнем углу профиль пользователя с кнопкой разлогина` },
    { id: 6, title: 'Лабораторная работа 6', path: '/lab6', description: `Реализовать или использовать простой REST сервер\nРеализовать несколько (GET, POST, PUT, DELETE) запросов на сервер используя промисы JS (fetch, axios).\nИспользовать формы (авторизации, регистрации, обратной связи) отправки данных на сервер из лабораторной работы №5.` },
    { id: 7, title: 'Лабораторная работа 7', path: '/lab7', description: `Внедрить в проект UI Kit Mui/Bootstrap или им подобное, для возможности адаптива.\nРеализовать Header (Главная, О себе) - отдельные страницы.\nИзменение темы на темную перенести в Header.\nПривести профиль пользователя в стандарт библиотеки Mui/Bootstrap\nРеализовать Menu (Drawer/Slider) - Меню по прежнему должно открывать список заданий лабораторных работ, но должно быть скрываемым и вызываться из Header по кнопке-иконке.\nВ нижнем меню организовать вызов быстрых действий (обратная связь и пр)\n* Проконтролировать, что приложение стало адаптивным под разные устройства.` }
  ];

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <Header
          onToggleDrawer={toggleDrawer}
          toggleDarkMode={toggleDarkMode}
          darkMode={darkMode}
          isLoggedIn={isLoggedIn}
        />
        <Menu open={isDrawerOpen} onClose={toggleDrawer} labWorks={labWorks} />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/about-app" element={<AboutApp />} />
          <Route
            path="/feedback"
            element={<Feedback reviews={reviews} addReview={addReview} deleteReview={deleteReview} isLoggedIn={isLoggedIn} />}
          />
          <Route
            path="/login"
            element={isLoggedIn ? <Navigate to="/" /> : <LoginForm onLogin={handleLogin} />}
          />
          <Route
            path="/register"
            element={isLoggedIn ? <Navigate to="/" /> : <RegistrationForm onRegister={handleRegistration} />}
          />
          <Route
            path="/profile"
            element={isLoggedIn ? <ProfileSettings username={isLoggedIn} logout={handleLogout} /> : <Navigate to="/login" />}
          />
          {labWorks.map((work) => (
            <Route
              key={work.id}
              path={work.path}
              element={<LabDescription description={work.description} title={work.title} />}
            />
          ))}
        </Routes>
        <Footer />
      </Router>
    </ThemeProvider>
  );
}

export default App;
