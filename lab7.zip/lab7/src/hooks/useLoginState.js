import { useState, useCallback } from 'react';

export const useLoginState = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(localStorage.getItem('username') || null);

  const login = useCallback((username) => {
    localStorage.setItem('username', username);
    setIsLoggedIn(username);
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem('username');
    setIsLoggedIn(null);
  }, []);

  return { isLoggedIn, login, logout };
};
