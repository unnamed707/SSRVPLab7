import React, { useState } from 'react';
import { TextField, Button, Container, Typography, Box } from '@mui/material';
import { useNavigate } from 'react-router-dom';

const
        event.preventDefault();
        if (passwordValue !== confirmPasswordValue) {
            alert('Пароли не совпадают');
            return;
        }

        // Здесь должна быть логика регистрации пользователя
        console.log('Регистрация:', { login: loginValue, password: passwordValue });
        // После успешной регистрации перенаправляем на страницу входа
        navigate('/login');
    };

    return (
        <Container maxWidth="sm">
            <Box sx={{ mt: 8, display: 'flex', flexDirection: 'column', alignItems: 'center'}
                        onChange={(e) => setConfirmPasswordValue(e.target.value)}
                    />
                    <Button
                        type="submit"
                        fullWidth
                        variant="contained"
                        sx={{ mt: 3, mb: 2 }}
                    >
                        Зарегистрироваться
                    </Button>
                </Box>
            </Box>
        </Container>
    );
};

export default RegistrationForm;
