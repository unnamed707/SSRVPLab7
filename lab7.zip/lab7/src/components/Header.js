import React, { useState } from 'react';
import { AppBar, Toolbar, Typography, IconButton, Switch, Box, Menu, MenuItem } from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import AccountCircle from '@mui/icons-material/AccountCircle';
import { Link, useNavigate } from 'react-router-dom';
import { useTheme } from '@mui/material/styles';

function Header({ onToggleDrawer, toggleDarkMode, darkMode, isLoggedIn }) {
  const theme = useTheme();
  const navigate = useNavigate();
  const [anchorEl, setAnchorEl] = useState(null);
  const isMenuOpen = Boolean(anchorEl);

  const handleProfileMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleLoginClick = () => {
    navigate('/login');
    handleMenuClose();
  };

  const handleRegistrationClick = () => {
    navigate('/register');
    handleMenuClose();
  };

  const handleProfileClick = () => {
    navigate('/profile');
    handleMenuClose();
  };

  return (
    <AppBar position="static">
      <Toolbar>
        <IconButton
          edge="start"
          color="inherit"
          aria-label="menu"
          onClick={onToggleDrawer}
          sx={{ mr: 2 }}
        >
          <MenuIcon />
        </IconButton>
        <Typography variant="h6" sx={{ flexGrow: 1 }}>
          Мой сайт
        </Typography>

        <Box sx={{ display: 'flex', alignItems: 'center', mr: 2 }}>
          <Typography>Светлая тема</Typography>
          <Switch checked={darkMode} onChange={toggleDarkMode} />
          <Typography>Темная тема</Typography>
        </Box>

        <Link to="/" style={{ color: 'white', textDecoration: 'none', marginLeft: '16px' }}>
          Главная
        </Link>
        <Link to="/about" style={{ color: 'white', textDecoration: 'none', marginLeft: '16px' }}>
          О себе
        </Link>
        {/* Убрали ссылку на "О приложении" отсюда */}

        <IconButton
          size="large"
          edge="end"
          aria-label="account of current user"
          aria-controls="profile-menu"
          aria-haspopup="true"
          onClick={handleProfileMenuOpen}
          color="inherit"
        >
          <AccountCircle />
        </IconButton>
        <Menu
          id="profile-menu"
          anchorEl={anchorEl}
          anchorOrigin={{
            vertical: 'top',
            horizontal: 'right',
          }}
          keepMounted
          transformOrigin={{
            vertical: 'top',
            horizontal: 'right',
          }}
          open={isMenuOpen}
          onClose={handleMenuClose}
        >
          {!isLoggedIn ? (
            <>
              <MenuItem onClick={handleLoginClick}>Войти</MenuItem>
              <MenuItem onClick={handleRegistrationClick}>Зарегистрироваться</MenuItem>
            </>
          ) : (
            <MenuItem onClick={handleProfileClick}>Профиль</MenuItem>
          )}
        </Menu>
      </Toolbar>
    </AppBar>
  );
}

export default Header;
