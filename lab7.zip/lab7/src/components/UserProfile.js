import React from 'react';
import { Avatar, Box, Typography, Button } from '@mui/material';

function UserProfile({ username, onLogout }) {
  return (
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, p: 1, color: 'white' }}>
      <Avatar alt={username} src="/static/images/avatar/1.jpg" />
      <Typography variant="subtitle1">{username}</Typography>
      <Button variant="outlined" color="inherit" onClick={onLogout}>
        Выйти
      </Button>
    </Box>
  );
}

export default UserProfile;
