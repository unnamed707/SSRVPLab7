import React from 'react';
import { Drawer, List, ListItem, ListItemText, ListItemButton } from '@mui/material';
import { Link } from 'react-router-dom';

function Menu({ open, onClose, labWorks }) {
  return (
    <Drawer anchor="left" open={open} onClose={onClose}>
      <List>
        {labWorks.map((work) => (
          <ListItem key={work.id} disablePadding>
            <ListItemButton component={Link} to={work.path} onClick={onClose}>
              <ListItemText primary={work.title} />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
    </Drawer>
  );
}

export default Menu;
