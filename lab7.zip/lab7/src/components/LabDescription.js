import React from 'react';
import { Container, Typography, Box } from '@mui/material';

function LabDescription({ description, title }) {
  return (
    <Container>
      <Typography variant="h4" gutterBottom>
        {title}
      </Typography>
      <Box mt={2} p={2} bgcolor="lightgray" borderRadius={1}>
        <Typography variant="body1" style={{ whiteSpace: 'pre-line' }}>
          {description}
        </Typography>
      </Box>
    </Container>
  );
}

export default LabDescription;
