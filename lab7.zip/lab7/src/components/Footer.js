import React from 'react';
import { BottomNavigation, BottomNavigationAction, Paper } from '@mui/material';
import FeedbackIcon from '@mui/icons-material/Feedback';
import InfoIcon from '@mui/icons-material/Info';
import { Link } from 'react-router-dom';
import { useMediaQuery, useTheme } from '@mui/material';

function Footer() {
  const [value, setValue] = React.useState(0);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  return (
    <Paper sx={{ position: 'fixed', bottom: 0, left: 0, right: 0 }} elevation={3}>
      <BottomNavigation
        showLabels
        value={value}
        onChange={(event, newValue) => {
          setValue(newValue);
        }}
      >
        <BottomNavigationAction label="Обратная связь" icon={<FeedbackIcon />} component={Link} to="/feedback" />
        <BottomNavigationAction label="О приложении" icon={<InfoIcon />} component={Link} to="/about-app" />
        {isMobile && (
          <BottomNavigationAction label="Дополнительно" icon={<InfoIcon />} component={Link} to="/more" />
        )}
      </BottomNavigation>
    </Paper>
  );
}

export default Footer;
