import React from 'react';
import { Typography, Container } from '@mui/material';

function Home() {
  return (
    <Container>
      <Typography variant="h4" gutterBottom>
        Главная страница
      </Typography>
      <Typography variant="body1">
        Добро пожаловать на мой сайт!
      </Typography>
    </Container>
  );
}

export default Home;
