import React, { useState, useCallback, useRef } from 'react';
import { Container, Typography, TextField, Button, Box } from '@mui/material';
import { useNavigate } from 'react-router-dom';

function ProfileSettings({ username: initialUsername, logout }) {
  const [username, setUsername] = useState(initialUsername);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();
  const initialValues = useRef({ username: initialUsername, password: '' }); // Сохраняем начальные значения


  const handleUsernameChange = (event) => {
    setUsername(event.target.value);
  };

  const handlePasswordChange = (event) => {
    setPassword(event.target.value);
  };

  const handleConfirmPasswordChange = (event) => {
    setConfirmPassword(event.target.value);
  };

  const handleSave = useCallback(() => {
    if (password !== confirmPassword) {
      setMessage('Пароли не совпадают');
      return;
    }

    if (username === 'admin') {
      setMessage('Имя пользователя admin не допустимо');
      return;
    }

    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key.startsWith('password_') && key !== `password_${initialUsername}` && key === `password_${username}`) {
        setMessage('Имя пользователя уже занято');
        return;
      }
    }

    const hasChanges = username !== initialValues.current.username || password !== ''; // Проверяем, были ли изменения

    if (!hasChanges) {
      setMessage('Нет изменений для сохранения');
      return;
    }

    localStorage.setItem('username', username);

    const oldPasswordKey = `password_${initialUsername}`;
    const newPasswordKey = `password_${username}`;
    const passwordValue = localStorage.getItem(oldPasswordKey);

    if (passwordValue) {
        localStorage.setItem(newPasswordKey, passwordValue);
        localStorage.removeItem(oldPasswordKey);
    }

    if (password) {
        localStorage.setItem(`password_${username}`, password);
    }

    initialValues.current = { username, password }; // Обновляем начальные значения

    setMessage('Профиль успешно обновлен');
  }, [username, password, confirmPassword, initialUsername]);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <Container maxWidth="sm">
      <Box mt={4}>
        <Typography variant="h4" align="center" gutterBottom>
          Настройки профиля
        </Typography>
        {message && (
          <Typography color={message.startsWith('Ошибка') ? 'error' : 'success'} align="center">
            {message}
          </Typography>
        )}
        <TextField
          label="Имя пользователя"
          variant="outlined"
          fullWidth
          margin="normal"
          value={username}
          onChange={handleUsernameChange}
        />
        <TextField
          label="Новый пароль"
          variant="outlined"
          fullWidth
          margin="normal"
          type="password"
          value={password}
          onChange={handlePasswordChange}
        />
        <TextField
          label="Подтвердите пароль"
          variant="outlined"
          fullWidth
          margin="normal"
          type="password"
          value={confirmPassword}
          onChange={handleConfirmPasswordChange}
        />
        <Button variant="contained" color="primary" fullWidth onClick={handleSave} sx={{ mt: 2 }}>
          Сохранить
        </Button>
        <Button variant="outlined" color="secondary" fullWidth onClick={handleLogout} sx={{ mt: 2 }}>
          Выйти
        </Button>
      </Box>
    </Container>
  );
}

export default ProfileSettings;
