import React from 'react';
import { Typography, Container } from '@mui/material';

function AboutApp() {
  return (
    <Container>
      <Typography variant="h4" gutterBottom>
        О приложении
      </Typography>
      <Typography variant="body1">
        Здесь будет информация о приложении.
      </Typography>
    </Container>
  );
}

export default AboutApp;
