import React, { useState, useCallback } from 'react';
import { Container, Typography, Box, TextField, Button, List, ListItem, ListItemText, IconButton } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';

function Feedback({ reviews, addReview, deleteReview, isLoggedIn }) {
  const [newReviewText, setNewReviewText] = useState('');

  const handleAddReview = useCallback(() => {
    if (newReviewText.trim()) {
      addReview({ text: newReviewText });
      setNewReviewText('');
    }
  }, [newReviewText, addReview]);

  const handleDeleteReview = useCallback((index) => {
    deleteReview(index);
  }, [deleteReview]);

  return (
    <Container sx={{ minHeight: 'calc(100vh - 128px)' }}> {/* Добавили минимальную высоту */}
      <Typography variant="h4" gutterBottom>
        Отзывы
      </Typography>

      {isLoggedIn ? (
        <Box mt={2}>
          <TextField
            label="Ваш отзыв"
            multiline
            rows={4}
            fullWidth
            variant="outlined"
            value={newReviewText}
            onChange={(e) => setNewReviewText(e.target.value)}
          />
          <Button variant="contained" color="primary" onClick={handleAddReview} sx={{ mt: 1 }}>
            Оставить отзыв
          </Button>
        </Box>
      ) : (
        <Typography variant="body1" sx={{ mt: 2 }}>
          Войдите, чтобы оставить отзыв.
        </Typography>
      )}

      <List sx={{ width: '100%', bgcolor: 'background.paper', mt: 3 }}>
        {reviews.map((review, index) => (
          <ListItem key={index} alignItems="flex-start">
            <ListItemText
              primary={review.author || 'Гость'}
              secondary={<React.Fragment>{review.text}</React.Fragment>}
            />
            {isLoggedIn === review.author && (
              <IconButton edge="end" aria-label="delete" onClick={() => handleDeleteReview(index)}>
                <DeleteIcon />
              </IconButton>
            )}
          </ListItem>
        ))}
      </List>
    </Container>
  );
}

export default Feedback;
