import React from 'react';
import { Typography, Container } from '@mui/material';

function About() {
  return (
    <Container>
      <Typography variant="h4" gutterBottom>
        О себе
      </Typography>
      <Typography variant="body1">
        Здесь будет информация обо мне.
      </Typography>
    </Container>
  );
}

export default About;
