import React from 'react';
import { Typography, Box } from '@mui/material';
import { useSelector } from 'react-redux';

const Profile = () => {
    const user = useSelector(state => state.auth.user); // Получаем информацию о пользователе из Redux

    return (
        <Box>
            <Typography variant="h4" gutterBottom>
                Профиль пользователя
            </Typography>
            {user && (
                <>
                    <Typography>
                        Имя пользователя: {user.username}
                    </Typography>
                    {/* Добавьте другие поля профиля, если необходимо */}
                    <Typography>
                        Роль: {user.role}
                    </Typography>
                </>
            )}
        </Box>
    );
};

export default Profile;
